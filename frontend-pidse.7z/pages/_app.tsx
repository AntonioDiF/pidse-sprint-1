import 'tailwindcss/tailwind.css';
import type { AppProps } from 'next/app';
import { Fragment } from 'react';
import Layout from '../components/layout/layout';
import { useRouter } from 'next/router';

function MyApp({ Component, pageProps }: AppProps) {
  const router = useRouter();
  const route = router.route;
  const NO_HEADERS = ['/', '/login', '/404'];

  const layout = NO_HEADERS.includes(route) ? (
    <Component {...pageProps} />
  ) : (
    <Layout title={router.route.substring(router.route.lastIndexOf('/') + 1)}>
      <Component {...pageProps} />
    </Layout>
  );

  return (
    <Fragment>
      <link rel='stylesheet' href='https://rsms.me/inter/inter.css' />
      {layout}
    </Fragment>
  );
}
export default MyApp;
