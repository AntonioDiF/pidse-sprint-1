import Link from 'next/link';

const grupos = [
  {
    id: 'A*7tauihak98y',
    nombre: 'Matemáticas 1',
    periodo: 'Agosto - Diciembre 2021',
    profesor: 'Miguel Rodríguez',
    alumnos: 40,
  },
  {
    id: 'Aisuy787f80sa',
    nombre: 'Física 2',
    periodo: 'Agosto - Diciembre 2021',
    profesor: 'Oscar Silva',
    alumnos: 30,
  },
];

function GroupsList() {
  return (
    <div className='flex flex-col'>
      <div className='-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8'>
        <div className='py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8'>
          <div className='shadow overflow-hidden border-b border-gray-200 sm:rounded-lg'>
            <table className='min-w-full divide-y divide-gray-200'>
              <thead className='bg-gray-50'>
                <tr>
                  <th
                    scope='col'
                    className='px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider'
                  >
                    Nombre
                  </th>
                  <th
                    scope='col'
                    className='px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider'
                  >
                    Periodo
                  </th>
                  <th
                    scope='col'
                    className='px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider'
                  >
                    Profesor
                  </th>
                  <th
                    scope='col'
                    className='px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider'
                  >
                    Alumnos
                  </th>
                  <th scope='col' className='relative px-6 py-3'>
                    <span className='sr-only'>Ver</span>
                  </th>
                </tr>
              </thead>
              <tbody className='bg-white divide-y divide-gray-200'>
                {grupos.map((grupo) => (
                  <tr key={grupo.id}>
                    <td className='px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900'>
                      {grupo.nombre}
                    </td>
                    <td className='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>
                      {grupo.periodo}
                    </td>
                    <td className='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>
                      {grupo.profesor}
                    </td>
                    <td className='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>
                      {grupo.alumnos}
                    </td>
                    <td className='px-6 py-4 whitespace-nowrap text-right text-sm font-medium'>
                      <Link href={`/groups/${grupo.id}`}>
                        <a className='text-indigo-600 hover:text-indigo-900'>
                          Ver
                        </a>
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

export default GroupsList;
