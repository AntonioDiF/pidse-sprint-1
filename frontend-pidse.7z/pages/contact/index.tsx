function ContactPage() {
  return (
    <div className='flex-1 p:2 sm:p-6 justify-between flex flex-col h-screen'>
      <div className='flex sm:items-center justify-between border-b-2 border-gray-200'>
        <div className='flex items-center space-x-4'>
          <div className='flex flex-col leading-tight'>
            <div className='text-2xl mt-1 flex items-center'>
              <span className='text-gray-700 mr-3'>Anderson Vanhron</span>
              <span className='text-green-500'>
                <svg width='10' height='10'>
                  <circle cx='5' cy='5' r='5' fill='currentColor'></circle>
                </svg>
              </span>
            </div>
            <span className='text-lg text-gray-600'>2° Preparatoria</span>
          </div>
        </div>
        <div className='flex items-center space-x-2'>
          <button
            type='button'
            className='inline-flex items-center justify-center rounded-full h-10 w-10 transition duration-500 ease-in-out text-gray-500 hover:bg-gray-300 focus:outline-none'
          >
            <svg
              xmlns='http://www.w3.org/2000/svg'
              fill='none'
              viewBox='0 0 24 24'
              stroke='currentColor'
              className='h-6 w-6'
            >
              <path
                strokeLinecap='round'
                strokeLinejoin='round'
                strokeWidth='2'
                d='M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z'
              ></path>
            </svg>
          </button>
        </div>
      </div>
      <div
        id='messages'
        className='flex flex-col space-y-4 p-3 overflow-y-auto scrollbar-thumb-blue scrollbar-thumb-rounded scrollbar-track-blue-lighter scrollbar-w-2 scrolling-touch'
      >
        <div className='chat-message'>
          <div className='flex items-end'>
            <div className='flex flex-col space-y-2 text-xs max-w-xs mx-2 order-2 items-start'>
              <div>
                <span className='px-4 py-2 rounded-lg inline-block rounded-bl-none bg-gray-300 text-gray-600'>
                  Buenas tardes, profesor. Queria preguntar si habrá
                  exposiciones desde el día lunes.
                </span>
              </div>
            </div>
          </div>
        </div>
        <div className='chat-message'>
          <div className='flex items-end justify-end'>
            <div className='flex flex-col space-y-2 text-xs max-w-xs mx-2 order-1 items-end'>
              <div>
                <span className='px-4 py-2 rounded-lg inline-block rounded-br-none bg-blue-600 text-white '>
                  Buenas tardes, Anderson. Así es, tal como lo platicamos la
                  última clase comenzaremos exposiciones.
                </span>
              </div>
            </div>
          </div>
        </div>
        <div className='chat-message'>
          <div className='flex items-end'>
            <div className='flex flex-col space-y-2 text-xs max-w-xs mx-2 order-2 items-start'>
              <div>
                <span className='px-4 py-2 rounded-lg inline-block bg-gray-300 text-gray-600'>
                  Entonces, ¿le toca a mi equipo pasar?
                </span>
              </div>
              <div>
                <span className='px-4 py-2 rounded-lg inline-block bg-gray-300 text-gray-600'>
                  ¿O se realizó algún tipo de asignación aleatoria?
                </span>
              </div>
              <div>
                <span className='px-4 py-2 rounded-lg inline-block bg-gray-300 text-gray-600'>
                  Como la última vez
                </span>
              </div>
              <div>
                <span className='px-4 py-2 rounded-lg inline-block rounded-bl-none bg-gray-300 text-gray-600'>
                  Para irnos preparando
                </span>
              </div>
            </div>
          </div>
        </div>
        <div className='chat-message'>
          <div className='flex items-end justify-end'>
            <div className='flex flex-col space-y-2 text-xs max-w-xs mx-2 order-1 items-end'>
              <div>
                <span className='px-4 py-2 rounded-lg inline-block rounded-br-none bg-blue-600 text-white '>
                  ¿Podrías recordarme tu número de equipo?
                </span>
              </div>
            </div>
          </div>
        </div>
        <div className='chat-message'>
          <div className='flex items-end'>
            <div className='flex flex-col space-y-2 text-xs max-w-xs mx-2 order-2 items-start'>
              <div>
                <span className='px-4 py-2 rounded-lg inline-block rounded-bl-none bg-gray-300 text-gray-600'>
                  El 5, profe, con Maya e Itu.
                </span>
              </div>
            </div>
          </div>
        </div>
        <div className='chat-message'>
          <div className='flex items-end justify-end'>
            <div className='flex flex-col space-y-2 text-xs max-w-xs mx-2 order-1 items-end'>
              <div>
                <span className='px-4 py-2 rounded-lg inline-block bg-blue-600 text-white '>
                  Perfecto, déjame reviso.
                </span>
              </div>
              <div>
                <span className='px-4 py-2 rounded-lg inline-block rounded-br-none bg-blue-600 text-white '>
                  Así es. Te toca segundo el día lunes.
                </span>
              </div>
            </div>
          </div>
        </div>
        <div className='chat-message'>
          <div className='flex items-end'>
            <div className='flex flex-col space-y-2 text-xs max-w-xs mx-2 order-2 items-start'>
              <div>
                <span className='px-4 py-2 rounded-lg inline-block bg-gray-300 text-gray-600'>
                  Perfecto, profe. ¡Muchísimas gracias! 😄
                </span>
              </div>
              <div>
                <span className='px-4 py-2 rounded-lg inline-block rounded-bl-none bg-gray-300 text-gray-600'>
                  Nos vemos el lunes.
                </span>
              </div>
            </div>
          </div>
        </div>
        <div className='chat-message'>
          <div className='flex items-end justify-end'>
            <div className='flex flex-col space-y-2 text-xs max-w-xs mx-2 order-1 items-end'>
              <div>
                <span className='px-4 py-2 rounded-lg inline-block rounded-br-none bg-blue-600 text-white '>
                  Nos vemos el lunes. Bonito fin de semana
                </span>
              </div>
            </div>
          </div>
        </div>
        <div className='chat-message'>
          <div className='flex items-end'>
            <div className='flex flex-col space-y-2 text-xs max-w-xs mx-2 order-2 items-start'>
              <div>
                <span className='px-4 py-2 rounded-lg inline-block bg-gray-300 text-gray-600'>
                  Bonito fin de semana también profe
                </span>
              </div>
              <div>
                <span className='px-4 py-2 rounded-lg inline-block bg-gray-300 text-gray-600'>
                  Au revoir!
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className='border-t-2 border-gray-200 px-4 pt-4 mb-2 sm:mb-0'>
        <div className='relative flex'>
          <input
            type='text'
            placeholder='Escribe algo...'
            className='w-full focus:outline-none focus:placeholder-gray-400 text-gray-600 placeholder-gray-600 pl-12 bg-gray-200 rounded-full py-3'
          />
          <div className='absolute right-0 items-center inset-y-0 hidden sm:flex'>
            <button
              type='button'
              className='inline-flex items-center justify-center rounded-full h-10 w-10 transition duration-500 ease-in-out text-gray-500 hover:bg-gray-300 focus:outline-none'
            >
              <svg
                xmlns='http://www.w3.org/2000/svg'
                fill='none'
                viewBox='0 0 24 24'
                stroke='currentColor'
                className='h-6 w-6 text-gray-600'
              >
                <path
                  strokeLinecap='round'
                  strokeLinejoin='round'
                  strokeWidth='2'
                  d='M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13'
                ></path>
              </svg>
            </button>
            <button
              type='button'
              className='inline-flex items-center justify-center rounded-full h-12 w-12 transition duration-500 ease-in-out text-white bg-blue-500 hover:bg-blue-400 focus:outline-none'
            >
              <svg
                xmlns='http://www.w3.org/2000/svg'
                viewBox='0 0 20 20'
                fill='currentColor'
                className='h-6 w-6 transform rotate-90'
              >
                <path d='M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z'></path>
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ContactPage;
