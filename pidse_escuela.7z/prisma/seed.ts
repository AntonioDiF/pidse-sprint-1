import prisma from "../lib/prisma"

const createPadre = async () => {
    await prisma.padre.createMany({
        data: [
            { nombre: 'Aquiles', apellidoMaterno: 'Castro', apellidoPaterno: 'Castro' },
            { nombre: 'Bob', apellidoMaterno: 'Gutierritos', apellidoPaterno: 'Gutierritos' },
            { nombre: 'Yewande', apellidoMaterno: 'Carpi', apellidoPaterno: 'Carpi' },
            { nombre: 'Angelique', apellidoMaterno: 'Aquino', apellidoPaterno: 'Aquino' },
        ]
    })
}

const createAlumno = async () => {
    await prisma.alumno.createMany({
        data: [
            {curp: "AIVA051116MPLLLZA9", nombre: 'Aquiles', apellidoMaterno: 'Castro', apellidoPaterno: 'Castro', id_padre:1 },
            {curp: "AARM050204HPLLNRA4", nombre: 'Bob', apellidoMaterno: 'Gutierritos', apellidoPaterno: 'Gutierritos', id_padre:2 }, 
            {curp: "AASW050113MMSLNNA8", nombre: 'Yewande', apellidoMaterno: 'Carpi', apellidoPaterno: 'Carpi', id_padre:3 },
            {curp: "BAAB050110MMSZLRA9", nombre: 'Angelique', apellidoMaterno: 'Aquino', apellidoPaterno: 'Aquino', id_padre:4 },
        ]
    })
}

const createMateria = async () => {
    await prisma.materia.createMany({
        data: [
            { nombre: "Matemáticas I" },
            { nombre: "Español" },
            { nombre: "Programación" },
            { nombre: "Educación física" }
        ]
    })
}

const createProfesor = async () => {
    await prisma.profesor.createMany({
        data: [
            { nombre: "Antonio", apellidoPaterno: "Calleros", apellidoMaterno: "Perez" },
            { nombre: "Oscar", apellidoPaterno: "Calleros", apellidoMaterno: "Perez" },
            { nombre: "Diego", apellidoPaterno: "Chulis", apellidoMaterno: "Perez" }
        ]
    })
}

const createCurso = async () => {
    await prisma.curso.createMany({
        data: [
            { periodo: "Enero 2021", id_profesor: 1, id_materia: 1 },
            { periodo: "Enero 2021", id_profesor: 2, id_materia: 2 },
            { periodo: "Enero 2021", id_profesor: 3, id_materia: 3 }
        ]
    })
}

const createCals = async () => {
    await prisma.calificacion.createMany({
        data: [
            { id_alumno: 1, id_curso: 1, calificacion: 69 },
            { id_alumno: 2, id_curso: 1, calificacion: 97 },
            { id_alumno: 3, id_curso: 1, calificacion: 97 },
            { id_alumno: 1, id_curso: 2, calificacion: 69 },
            { id_alumno: 2, id_curso: 2, calificacion: 97 },
            { id_alumno: 3, id_curso: 2, calificacion: 97 },
            { id_alumno: 1, id_curso: 3, calificacion: 69 },
            { id_alumno: 2, id_curso: 3, calificacion: 97 },
            { id_alumno: 3, id_curso: 3, calificacion: 97 }
        ]
    })
}


createPadre();
createAlumno();
createMateria();
createProfesor();
createCurso();
createCals();