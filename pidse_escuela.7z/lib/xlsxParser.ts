import readXlsxFile from 'read-excel-file/node'
import { Alumno, Calificacion, InfoGrupo, XlsxAlumnosInfo } from '../Types/types';

const getMaterias = (row: any[]): string[] => {
    let materias = []
    let i = 7
    while (row[i] !== null) {
        materias.push(row[i]);
        ++i;
    }
    
    return materias;
} 

const getGroupInfo = (row: any[]): InfoGrupo => {
    let info: InfoGrupo = {grado:"",grupo:"",periodo:""}
    info.grado = row[8]
    info.grupo = row[11]
    info.periodo = row[14]
    return info
}

const getCalificaciones = (row: any[], materias: string[]): Calificacion[] => {
    let i = 7
    let calificaciones: Calificacion[] = []
    while (row[i] !== null && row[i] !== undefined) {
        calificaciones.push( { nombreMateria: materias[i-7], nota: row[i] } )
        ++i;
    }
    return calificaciones;
}

const buildAnswer = (rows: any[]): XlsxAlumnosInfo => {
    let answer: XlsxAlumnosInfo = {alumnos:[],infoGrupo:{grado:"",grupo:"",periodo:""}};
    let materias = getMaterias(rows[10]);
    answer.infoGrupo = getGroupInfo(rows[4]);
    answer.materias = materias
    let i = 11;
    let alumnos: Alumno[] = []
    while (rows[i][0] !== null) {
        let alumno: Alumno = {curp:"", nombre:"", calificaciones: []}
        alumno.curp = rows[i][1]
        if(alumno.curp !== null && alumno.curp.includes("-")) break;
        alumno.nombre = rows[i][4]
        alumno.calificaciones = getCalificaciones(rows[i], materias);
        alumnos.push(alumno)
        ++i
    }
    answer.alumnos = alumnos
    return answer
}

const getInfo = async (sheet: number, path: string): Promise<XlsxAlumnosInfo> => {
    return readXlsxFile(path, { sheet }).then((rows: any[]) => {
       return buildAnswer(rows)
    }).catch((e) => {
        console.log(e)
        return {alumnos:[],infoGrupo:{grado:"",grupo:"",periodo:""}}
    })
}


export default getInfo;