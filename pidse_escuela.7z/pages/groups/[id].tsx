type alumno_tipo = {
  id: string;
  nombre: string;
  estado: string;
  calificación: number;
};

const alumnos: alumno_tipo[] = [
  {
    id: 'A*7tauihak98y',
    nombre: 'Luis Serrano Domínguez',
    estado: 'Activo',
    calificación: 90,
  },
  {
    id: 'uihak98y',
    nombre: 'Domingo Carrillo Fabio',
    estado: 'Desconectado',
    calificación: 72,
  },
  {
    id: 'A*7tauihy',
    nombre: 'Fernando Montes Castro',
    estado: 'Ocupado',
    calificación: 81,
  },
  {
    id: 'A*7hak98y',
    nombre: 'Ramón Juárez Díaz',
    estado: 'Activo',
    calificación: 92,
  },
  {
    id: '7tauih8y',
    nombre: 'Aquiles Violeta Paredes',
    estado: 'Activo',
    calificación: 100,
  },
  {
    id: 'A8y',
    nombre: 'Fabián Ramos Vega',
    estado: 'Ocupado',
    calificación: 25,
  },
  {
    id: 'A*7tauihak98y',
    nombre: 'Andrea Aquino Baeza',
    estado: 'Desconectado',
    calificación: 90,
  },
];

const clases_estado: { [key: string]: string } = {
  Activo: 'bg-green-100 text-green-800',
  Ocupado: 'bg-yellow-100 text-yellow-800',
  Desconectado: 'bg-gray-100 text-gray-800',
};

function GroupsDetail() {
  return (
    <div className='flex flex-col'>
      <div className='-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8'>
        <div className='py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8'>
          <div className='shadow overflow-hidden border-b border-gray-200 sm:rounded-lg'>
            <table className='min-w-full divide-y divide-gray-200'>
              <thead className='bg-gray-50'>
                <tr>
                  <th
                    scope='col'
                    className='px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider'
                  >
                    Nombre
                  </th>
                  <th
                    scope='col'
                    className='px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider'
                  >
                    Estado
                  </th>
                  <th
                    scope='col'
                    className='px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider'
                  >
                    Calificación
                  </th>
                  <th scope='col' className='relative px-6 py-3'>
                    <span className='sr-only'>Contactar</span>
                  </th>
                </tr>
              </thead>
              <tbody className='bg-white divide-y divide-gray-200'>
                {alumnos.map((alumno) => (
                  <tr key={alumno.id}>
                    <td className='px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900'>
                      {alumno.nombre}
                    </td>
                    <td className='px-6 py-4 whitespace-nowrap'>
                      <span
                        className={
                          'px-2 inline-flex text-xs leading-5 font-semibold rounded-full ' +
                          clases_estado[alumno.estado]
                        }
                      >
                        {alumno.estado}
                      </span>
                    </td>
                    <td className='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>
                      {alumno.calificación}
                    </td>
                    <td className='px-6 py-4 whitespace-nowrap text-right text-sm font-medium'>
                      <a
                        href='#'
                        className='text-indigo-600 hover:text-indigo-900'
                      >
                        Contactar
                      </a>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

export default GroupsDetail;
