import nextConnect from 'next-connect';
import multer from 'multer';
import getInfo from '../../../lib/xlsxParser';

import prisma from "../../../lib/prisma"
import { Alumno, XlsxAlumnosInfo } from '../../../Types/types';

const upload = multer({
  storage: multer.diskStorage({
    destination: './public/uploads',
    filename: (req, file, cb) => cb(null, file.originalname),
  }),
});

const apiRoute = nextConnect({
  onError(error, req, res:any) {
    res.status(501).json({ error: `Sorry something Happened! ${error.message}` });
  },
  onNoMatch(req, res:any) {
    res.status(405).json({ error: `Method '${req.method}' Not Allowed` });
  },
});

apiRoute.use(upload.array('thefiles'));

const createMaterias = async (materias: string[] = []): Promise<void> => {
  materias.map(async (el: any) => {
    let isInBase = await prisma.materia.findFirst({where: {
      nombre: el,
    }})
    if (isInBase === null) {
      await prisma.materia.create({ data: { nombre: el } })
    }
  })
}

const createAlumno = async (alumnos: Alumno[] = []): Promise<void> => {
  alumnos.map(async (el: Alumno) => {
    let isInBase = await prisma.alumno.findFirst({where: {
      curp: el.curp,
    }})
    if (isInBase === null) {
      await prisma.alumno.create({ data: { nombre: el.nombre, curp: el.curp, apellidoMaterno: "", apellidoPaterno: "" } })
    }
  })
}

const saveData = async (info: XlsxAlumnosInfo) => {
  await createMaterias(info.materias);
  await createAlumno(info.alumnos);
}

apiRoute.post(async(req:any, res:any) => {
  for (let index = 0; index < 3; index++) {
    let grado = await getInfo(index+1,req.files[0].path)
    //console.log(grado)
    await saveData(grado);
  }

  res.status(200).json({ data: 'success' });
});

export default apiRoute;

export const config = {
  api: {
    bodyParser: false, // Disallow body parsing, consume as stream
  },
};