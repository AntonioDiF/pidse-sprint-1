import { Profesor } from '.prisma/client';
import type { NextApiRequest, NextApiResponse } from 'next'
import nextConnect from 'next-connect';
import prisma from "../../../lib/prisma"
import { ErrorMessage } from '../../../Types/types';

/* Función para obtener parámetro de la URL y verifificar si es un número */
const getRoute = (params: { [key: string]: string | string[]; }): number | undefined => {
    const { profesorid } = params
    let id = typeof (profesorid) == "string" && !isNaN(Number.parseInt(profesorid)) ? Number.parseInt(profesorid) : undefined
    return id
}


/* Llamada a la base para obtener el profesor solicitado por ID */
const getProfesor = async(id: number): Promise<Profesor|null> => {
    return await prisma.profesor.findUnique({
        where: {
            id
        },
        include: {
            cursos: true
        }
    })
}

const handler = nextConnect()
    /* Get de un sólo objeto profesor */
    .get(async (req: NextApiRequest, res: NextApiResponse<Profesor | ErrorMessage | {}>) => {
        let route = getRoute(req.query);
        if (route === undefined) res.status(404).json({ error: "Ruta no encontrada", status: 404 }) /* Error en la ruta */
        else {
            try {
                const profesor = await getProfesor(route) 
                if (profesor === null) res.status(200).json({})
                else res.status(200).json(profesor)
            } catch(e) { /* Algo fallo en la conexión entre la base y Prisma */
                res.status(500).json({ error: "Error en conexión a la base", status: 500 })
            }
        }

    })

export default handler;