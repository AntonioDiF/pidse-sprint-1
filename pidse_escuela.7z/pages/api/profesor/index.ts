import { Profesor } from '.prisma/client';
import type { NextApiRequest, NextApiResponse } from 'next'
import nextConnect from 'next-connect';
import prisma from "../../../lib/prisma"
import { ErrorMessage } from '../../../Types/types';

/* Llamada a la base para obtener profesores */
const getProfesores = async(): Promise<Profesor[] | null> => {
    return await prisma.profesor.findMany({
        include: {
            cursos: true
        }
    })
}

const handler = nextConnect()
    .get(async (req: NextApiRequest, res: NextApiResponse<Profesor[] | ErrorMessage>) => {
        try {
            const profesores = await getProfesores()
            if(profesores === null) res.status(200).json([]) /* Enviar arreglo vacion si no se encuentra nada en base */
            else res.status(200).json(profesores)
        } catch (e) { /* Algo fallo en la conexión entre la base y Prisma */
            res.status(500).json({ error: "Error en conexión a la base", status: 500 })
        }
    })

export default handler;