import { Materia } from '.prisma/client';
import type { NextApiRequest, NextApiResponse } from 'next'
import nextConnect from 'next-connect';
import prisma from "../../../lib/prisma"
import { ErrorMessage } from '../../../Types/types';

/* Llamada a la base para obtener materias */
const getMaterias = async(): Promise<Materia[] | null> => {
    return await prisma.materia.findMany({
        include: {
            cursos: true
        }
    })
}


const handler = nextConnect()
    .get(async (req: NextApiRequest, res: NextApiResponse<Materia[] | ErrorMessage>) => {
        try {
            const materias = await getMaterias()
            if (materias === null) res.status(200).json([]) /* Enviar arreglo vacion si no se encuentra nada en base */
            else res.status(200).json(materias)
        } catch (e) { /* Algo fallo en la conexión entre la base y Prisma */
            res.status(500).json({ error: "Error en conexión a la base", status: 500 })
        }
    })

export default handler;