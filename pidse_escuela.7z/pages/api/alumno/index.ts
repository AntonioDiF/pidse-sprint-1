import { Alumno } from '.prisma/client';
import type { NextApiRequest, NextApiResponse } from 'next'
import nextConnect from 'next-connect';
import prisma from "../../../lib/prisma"
import { ErrorMessage } from '../../../Types/types';

/* Llamada a la base para obtener alumnos */
const getAlumnos = async(): Promise<Alumno[] | null> => {
    return await prisma.alumno.findMany({
        include: {
            calificaciones: true
        }
    })
}

const handler = nextConnect()
    .get(async (req: NextApiRequest, res: NextApiResponse<Alumno[] | ErrorMessage>) => {
        try {
            const alumnos = await getAlumnos()
            if (alumnos === null) res.status(200).json([]) /* Enviar arreglo vacion si no se encuentra nada en base */
            else res.status(200).json(alumnos)
        } catch (e) { /* Algo fallo en la conexión entre la base y Prisma */
            res.status(500).json({ error: "Error en conexión a la base", status: 500 })
        }
    })

export default handler;