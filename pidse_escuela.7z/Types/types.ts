export type ErrorMessage = {
    error: string
    status: number
}

export type InfoGrupo = {
    grado: string
    grupo: string
    periodo: string
}

export type XlsxAlumnosInfo = {
    materias?: string[]
    infoGrupo: InfoGrupo
    alumnos: Alumno[]
}

export type Calificacion = {
    nota: number
    nombreMateria: string
}

export type Alumno = {
    curp: string
    nombre: string
    calificaciones: Calificacion[]
}