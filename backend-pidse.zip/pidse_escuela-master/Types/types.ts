export type ErrorMessage = {
    error: string
    status: number
}
