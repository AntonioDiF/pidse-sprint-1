import { Calificacion } from '.prisma/client';
import type { NextApiRequest, NextApiResponse } from 'next'
import nextConnect from 'next-connect';
import prisma from "../../../lib/prisma"
import { ErrorMessage } from '../../../Types/types';

/* Llamada a la base para obtener calificaciones */
const getCalificaciones = async(): Promise<Calificacion[] | null> => {
    return await prisma.calificacion.findMany({
        include: {
            alumno: true,
            curso: true
        }
    })
}

const handler = nextConnect()
    .get(async (req: NextApiRequest, res: NextApiResponse<Calificacion[] | ErrorMessage>) => {
        try {
            const calificaciones = await getCalificaciones()
            if (calificaciones === null) res.status(200).json([]) /* Enviar arreglo vacion si no se encuentra nada en base */
            else res.status(200).json(calificaciones)
        } catch (e) { /* Algo fallo en la conexión entre la base y Prisma */
            res.status(500).json({ error: "Error en conexión a la base", status: 500 })
        }
    })

export default handler;