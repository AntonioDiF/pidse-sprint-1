import { Materia } from '.prisma/client';
import type { NextApiRequest, NextApiResponse } from 'next'
import nextConnect from 'next-connect';
import prisma from "../../../lib/prisma"
import { ErrorMessage } from '../../../Types/types';

/* Función para obtener parámetro de la URL y verifificar si es un número */
const getRoute = (params: { [key: string]: string | string[]; }): number | undefined => {
    const { materiaid } = params
    let id = typeof (materiaid) == "string" && !isNaN(Number.parseInt(materiaid)) ? Number.parseInt(materiaid) : undefined
    return id
}

/* Llamada a la base para obtener la materia solicitada por ID */
const getMateria = async(id: number): Promise<Materia|null> => {
    return await prisma.materia.findUnique({
        where: {
            id
        },
        include: {
            cursos: true
        }
    })
}

const handler = nextConnect()
    /* Get de un sólo objeto materia */
    .get(async (req: NextApiRequest, res: NextApiResponse<Materia | ErrorMessage | {}>) => {
        let route = getRoute(req.query);
        if (route === undefined) res.status(404).json({ error: "Ruta no encontrada", status: 404 }) /* Error en la ruta */
        else {
            try {
                const materia = await getMateria(route) 
                if (materia === null) res.status(200).json({})
                else res.status(200).json(materia)
            } catch(e) { /* Algo fallo en la conexión entre la base y Prisma */
                res.status(500).json({ error: "Error en conexión a la base", status: 500 })
            }
        }

    })

export default handler;